package com.example.myapplication;

public class Responses {
    private String RESPONSE;

    public String getResponse() {
        return RESPONSE;
    }
}
