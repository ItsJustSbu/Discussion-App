package com.example.myapplication;

public class Data {
      private String TITLE, QUESTION, AUTHOR, VOTES;

      public String getTitle() {
            return TITLE;
      }

      public String getQuestion() {
            return QUESTION;
      }

      public String getAuthor() {
            return AUTHOR;
      }

      public String getVotes() {
            return VOTES;
      }
}
